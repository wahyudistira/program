<div class="span9">
		<ul class="breadcrumb wellwhite">
			<li><a href="<?=base_URL()?>">Beranda</a> <span class="divider">/</span></li>
			<li>Profil <span class="divider">/</span></li>
			<li><?=$profil->judul?></li>
			
		</ul>
		
		 <div class="span12 wellwhite" style="margin-left: 0px">
		  <legend><?=$profil->judul?></legend>
		  
		  <p><?=$profil->isi?></p>

		</div>