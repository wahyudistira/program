 <div class="span9">
		<ul class="breadcrumb wellwhite">
			<li><a href="<?=base_URL()?>">Beranda</a> <span class="divider">/</span></li>
			<li><a href="<?=base_URL()?>index.php/tampil/blog">Blogpost</a> <span class="divider">/</span></li>
			<li>Invalid Post ID</li>
			
		</ul>
		
		<div class='alert alert-error'>Invalid Post ID.</div>
		 
</div>