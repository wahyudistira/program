<div class="clearfix"></div>
		
		<footer>
			<p>
				<span style="text-align:left;float:left"><?php echo $GLOBALS['site_title']; ?></span>
				<span class="hidden-phone" style="text-align:right;float:right"><?php echo $GLOBALS['site_quotes']; ?></a></span>
			</p>

		</footer>
				
	</div>
	
</body>
</html>
