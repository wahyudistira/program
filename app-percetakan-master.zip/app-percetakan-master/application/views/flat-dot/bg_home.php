<div id="content" class="span11">
<div class="row-fluid sortable">		
	<div class="box span12">
		<div class="box-header" data-original-title="">
			<h2><i class="halflings-icon home"></i><span class="break"></span>Dashboard</h2>
		</div>
		<div class="box-content">
			  Welcome, "<?php echo $this->session->userdata("nama_user_login"); ?>"
		</div>
	</div>

</div>
</div>
</div>